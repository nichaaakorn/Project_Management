namespace graphql_aspnet_core.Data
{
    public partial class OrgChartShape
    {
        public int Id { get; set; }
        public string Color { get; set; }
        public string JobTitle { get; set; }
    }
}
