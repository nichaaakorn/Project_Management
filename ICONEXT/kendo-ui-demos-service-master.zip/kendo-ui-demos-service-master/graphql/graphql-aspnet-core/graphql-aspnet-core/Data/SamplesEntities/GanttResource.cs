namespace graphql_aspnet_core.Data
{
    public partial class GanttResource
    {
        public int ID { get; set; }
        public string Color { get; set; }
        public string Name { get; set; }
    }
}
