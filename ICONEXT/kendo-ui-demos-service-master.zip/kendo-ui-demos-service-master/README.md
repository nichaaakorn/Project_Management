# kendo-ui-demos-service
Back-end service used for the [Kendo UI Online Demos](http://demos.telerik.com/kendo-ui/)

This is an ASP.NET MVC application, but it doesn't need to be. Any other server framework will work just as well.
