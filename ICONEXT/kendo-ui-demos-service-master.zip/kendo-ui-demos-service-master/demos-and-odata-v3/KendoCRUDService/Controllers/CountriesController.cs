﻿using System.Web.Mvc;
using KendoCRUDService.Models;
using KendoCRUDService.Common;

namespace KendoCRUDService.Controllers
{
    public class CountriesController : Controller
    {
        public ActionResult Index()
        {
            return this.Jsonp(CountryRepository.All());
        }
    }
}
