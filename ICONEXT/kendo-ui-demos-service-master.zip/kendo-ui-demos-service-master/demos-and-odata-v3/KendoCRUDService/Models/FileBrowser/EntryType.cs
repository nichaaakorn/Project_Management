﻿namespace KendoCRUDService.Models
{
    public enum EntryType
    {
        File = 0,
        Directory
    }
}
