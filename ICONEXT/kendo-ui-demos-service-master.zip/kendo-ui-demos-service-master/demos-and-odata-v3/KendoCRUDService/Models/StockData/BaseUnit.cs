﻿namespace KendoCRUDService.Models
{
    public enum BaseUnit
    {
        Years = 0,
        Months = 1,
        Weeks = 2,
        Days = 3,
        Hours = 4,
        Minutes = 5
    }
}