﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KendoCRUDService.Models
{
    public static class DatabaseSettings
    {
        public static bool UpdateDatabase = true;
    }
}