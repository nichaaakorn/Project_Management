using System;
using System.Collections.Generic;

namespace signalr_for_aspnet_core.Models
{
    public partial class GanttResource
    {
        public int ID { get; set; }
        public string Color { get; set; }
        public string Name { get; set; }
    }
}
