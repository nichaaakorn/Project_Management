using System;
using System.Collections.Generic;

namespace signalr_for_aspnet_core.Models
{
    public partial class OrgChartShape
    {
        public int Id { get; set; }
        public string Color { get; set; }
        public string JobTitle { get; set; }
    }
}
