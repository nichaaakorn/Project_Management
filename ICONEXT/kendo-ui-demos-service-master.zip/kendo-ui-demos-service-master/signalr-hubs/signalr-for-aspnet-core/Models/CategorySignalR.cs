﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace signalr_for_aspnet_core.Models
{
    public class CategorySignalR
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
    }
}