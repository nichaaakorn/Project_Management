﻿using System.Web;
using System.Web.Mvc;

namespace kendo_northwind_pg
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
